# Realistic Spears

- ever wanted to use spears like actual spears in Valheim?

- Now you can! 

- This mod changes the attack animations of spears to use the sword secondary attack animation instead of the poke attack animation.

- It also doubles the animation speed to make it feel more responsive, using Blaxxun's AnimationSpeedManager as a library. (to hopefully avoid compatibility issues)

- slight tweaks to the spear attack range and angle to make it more balanced and feel natural.

- This release is for testing and feedback within my small community, and it has not been tested for crossplay.