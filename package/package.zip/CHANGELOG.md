# v0.1.0
- Initial beta of Realistic Spears mod. For testing and feedback.
